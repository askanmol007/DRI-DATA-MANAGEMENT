import FormField from './FormField';

import { useState } from 'react';
import { useAppContext } from '../context/appContext';

const statusOptions=['Regular','Outstanding']
const placeOptions=["Ajmer","Delhi"]

const SearchContainer = () => {
  const [form,setForm]=useState({
    status:"all",
    place:"all",
    yearOfPurchase:"",
    customerName:"",
    
  });
  const {getAllData}=useAppContext();

  const  handleChange=(e)=>{
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  }
  const handleSearch = (e) => {
    // if (isLoading) return;
    handleChange({ name: e.target.name, value: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    getAllData(form); 
  };
  
  return (
    <div className=' w-10/12 mx-auto mt-5 '>
      <form className='form'>
        
        {/* search position */}
        <div className='form-center'>
         <div className='flex justify-center'>
           {/* customer name */}
        <div>
          <div className='flex items-center gap-2 mb-2'>
          <label 
          htmlFor={"customerName"}
          className="block text-sm font-medium text-gray-900"
          >
            {"Customer Name"}
          </label>
          </div>
          <input
          type={"text"}
          id={form.customerName}
          name={form.customerName}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-[#6469ff] focus:border-[#6469ff] outline-none block w-full p-3"
          value={form.customerName}
          onChange={handleChange}
          />
        </div>
       {/* yearOfPurchase */}
        <div>
          <div className='flex items-center gap-2 mb-2'>
          <label 
          htmlFor={"yearOfPurchase"}
          className="block text-sm font-medium text-gray-900"
          >
            {"Year Of purchase"}
          </label>
          </div>
          <input
          type={"number"}
          id={form.yearOfPurchase}
          name={form.yearOfPurchase}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-[#6469ff] focus:border-[#6469ff] outline-none block w-full p-3"
          value={form.yearOfPurchase}
          onChange={handleChange}
          />
        </div>
         </div>
          {/* status select */}
       
          <div className='flex justify-center'>
          <div className='form-row'>
          <label htmlFor={'status'} className='form-label'>
            {'status'}
          </label>
    
          <select
            name={'status'}
            value={form.status}
            onChange={handleChange}
            className='form-select'
          >
            {['all',...statusOptions].map((itemValue, index) => {
              return (
                <option key={index} value={itemValue}>
                  {itemValue}
                </option>
                );
              })}
            </select>
          </div>
          {/* jobType select */}
          <div className='form-row'>
          <label htmlFor={'place'} className='form-label'>
            {'place'}
          </label>
    
          <select
            name={'searchType'}
            value={form.place}
            onChange={handleSearch}
            className='form-select'
          >
            {['all',...placeOptions].map((itemValue, index) => {
              return (
                <option key={index} value={itemValue}>
                  {itemValue}
                </option>
                );
              })}
            </select>
          </div>
          </div>
          {/* sort select */}
          {/* <div className='form-row'>
          <label htmlFor={'sort'} className='form-label'>
            {'sort'}
          </label>
    
          <select
            name={'sort'}
            value={sort}
            onChange={handleSearch}
            className='form-select'
          >
            {['all',...sortOptions].map((itemValue, index) => {
              return (
                <option key={index} value={itemValue}>
                  {itemValue}
                </option>
                );
              })}
            </select>
          </div> */}
          {/* clear btn */}
          <button
            className='btn btn-block btn-danger'
            // disabled={0}
            onClick={handleSubmit}
          >
            apply filters
          </button>

          
        </div>
      </form>
    </div>
  );
};

export default SearchContainer;