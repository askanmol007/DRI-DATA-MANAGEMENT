import reducer from "./reducer";
import axios from "axios";

import {
    UPLOAD_DATA_SUCCESS,
    UPLOAD_DATA_FAIL,
    API_CALL_BEGIN,
    API_CALL_FAIL,
    GET_USER_SUCCESS,
    GET_USER_FAIL,
    LOGOUT_USER,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,
    SET_FILE,
    SIGNUP_USER_SUCCESS,
    SIGNUP_USER_FAIL,
    
   
    
} from './action'
import React, { useReducer, useContext,useEffect } from 'react';



export const initialState  ={
    isLoading:false,
    isAuthenticated:false,
    user:null,
    isAdmin:false,
    mainData:[],
    file:null,
    message:"",
    search: '',
  searchStatus: 'all',
  searchType: 'all',
  sort: 'latest',
  sortOptions: ['latest', 'oldest', 'a-z', 'z-a'],
     
}
const AppContext = React.createContext();

const AppProvider = ({ children }) => {
  
  const [state, dispatch] = useReducer(reducer,initialState);
  // axios --base url
  const instance = axios.create({
    // development->
     baseURL: 'call/api/v1'
    // production
    // baseURL: '/api/v1',
    
  });

  const setFile=(file)=>{
    dispatch({type:SET_FILE,payload:file});  
  } 
    
   const logoutUser =async()=>{
      await instance.get('/auth/logout');
      dispatch({type:LOGOUT_USER});  
    }
    
    const signupUser=async (currUser)=>{
      dispatch({type:API_CALL_BEGIN});
      try {
        const {data}= await instance.post('/auth/signup',currUser);
          dispatch({
            type:SIGNUP_USER_SUCCESS,
            payload:data.user
          })
      } catch (error) {
        dispatch({type:SIGNUP_USER_FAIL})
        if (error.response && error.response.data && error.response.data.message) {
          return  alert(error.response.data.message);
        } 
        
        alert(error.message || 'something went wrong tru later');
      }
    }

    const loginUser=async(currUser)=>{
      dispatch({type:API_CALL_BEGIN});
      
      try{
        const {data} =await instance.post('/auth/login',currUser);
        
        dispatch({ 
          type:LOGIN_USER_SUCCESS,
          payload:data.user
        })
      }catch(error){
        dispatch({type:LOGIN_USER_FAIL})
        if (error.response && error.response.data && error.response.data.message) {
          return  alert(error.response.data.message);
        } 
        
        alert(error.message || 'something went wrong tru later');
      }

    }
    const getCurrUser=async()=>{
        dispatch({type:API_CALL_BEGIN});
        try{
          const {data}= await instance.get('/auth/getCurrUser');
          dispatch({
            type:GET_USER_SUCCESS,
            payload:data?.user
          })
        }catch(err){
          
          if (err.response.status === 401) {
           
            return;
          };
          dispatch({type:GET_USER_FAIL})
          logoutUser();
          // console.log(err.responce.data.msg);
        }
    }
    // logoutUser();
    // useEffect(() => {
    //   getCurrUser();
    // }, []);
    // ADMIN
    
     const getAllData=async(queryObject)=>{
      console.log(queryObject);

      const {status,place,yearOfPurchase,customerName}=queryObject;

      dispatch({type:API_CALL_BEGIN});
      // &status=${status}&place=${place}&customerName=${customerName}
      
      try {
        const {data}= await instance.get(`/getData?yearOfPurchase=${1995}`)
       console.log(data)
        dispatch({type:GET_ALL_DATA_SUCCESS,
          payload:data.result
        })
      } catch (error) {
        dispatch({type:API_CALL_FAIL});
      }
    }

    const UploadData=async(file)=>{
     
      console.log("1") 
      console.log(file);
      dispatch({type:API_CALL_BEGIN});
      console.log("4")
      try {
        const {data}= await instance.post('/upload', file, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        console.log(data)
        dispatch({type:UPLOAD_DATA_SUCCESS,
          payload:data.message
        })
        alert(data.message);
      } catch (error) {
        console.log("3")
        dispatch({type:UPLOAD_DATA_FAIL, payload:error.message});
        // alert(error.message);
      }
    }
    // const changeRole=async(userId,userRole)=>{
    //   dispatch({type:API_CALL_BEGIN});
      
    //   try {
    //     let obj={role:"admin"};
    //     if(userRole==="admin") obj={role:"user"}
    //     console.log(obj);
    //     console.log("hi");


    //     const {data}= await instance.patch(`/auth/admin/user/${userId}`,obj)
       
    //     dispatch({type:CHANGE_ROLE__SUCCESS,
    //       payload:data.users
    //     })
    //     // console.log(data.user)
    //   } catch (error) {
    //     dispatch({type:API_CALL_FAIL});
    //   }
    // }
    // const deleteUser=async(userId)=>{
    //   dispatch({type:API_CALL_BEGIN});
      
    //   try {
    //     const {data}= await instance.delete(`/auth/admin/user/${userId}`)
       
    //     dispatch({type:DELETE_USER_SUCCESS,
    //       payload:data.users
    //     })
    //     // console.log(data.message);
    //   } catch (error) {
    //     dispatch({type:API_CALL_FAIL});
    //   }
    // }
   
    return (
        <AppContext.Provider
          value={{...state,
            setFile,UploadData,getAllData,
            signupUser,loginUser,logoutUser,getCurrUser}}
        >
          {children}
        </AppContext.Provider>
      );
}
export const useAppContext = () => {
    return useContext(AppContext);
  };
  
  export { AppProvider };