import React from 'react'
import { SearchContainer } from '../../components'
const Data = () => {
    
  return (
    <div>
      <SearchContainer/>
    </div>
  )
}

export default Data
