import AdminDash from "./AdminDash";
import Data from "./Data";
import Team from "./Team";
import Upload from "./Upload";


export {Data,Team,Upload,AdminDash}