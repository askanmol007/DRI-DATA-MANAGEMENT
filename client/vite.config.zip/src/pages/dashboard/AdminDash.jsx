import React from 'react'
import {Link,Outlet,NavLink} from  'react-router-dom'

const links=[
  {
    to:"/admin",
    text:"Upload"

  },
  {
    to:"data",
    text:"Data"

  },
  {
    to:"team",
    text:"Our Team"

  }
  

]

const AdminDash = () => {
  return (
    <div className='flex '>
      {/* side bar */}
      <div className='w-2/12 py-4'>
        <div className=' flex py-2 px-3'>
        <div className='font-bold text-lg text-[2.5rem]'> LOGO</div>
        </div>
        <ul className='mt-8 flex flex-col w-full justify-center px-[2rem] text-[1.1rem]'>
         {links.map((obj)=>{
          return <li key={obj.text} className='mt-4  border-b p-2'> <NavLink end={obj.to==='/admin'} className={({isActive})=>isActive?" text-[#fd79a8] transform translate-x-20":""} to={obj.to}>{obj.text} </NavLink>  </li>
         })}
        </ul>
      </div>
      
      {/* main view */}
      <div className='w-10/12 '>
        {/* nav */}
        <div className='flex justify-evenly py-4 items-center'>
          
          <p className='flex items-center text-xl'>
            <span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
              <path fillRule="evenodd" d="M18.685 19.097A9.723 9.723 0 0021.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 003.065 7.097A9.716 9.716 0 0012 21.75a9.716 9.716 0 006.685-2.653zm-12.54-1.285A7.486 7.486 0 0112 15a7.486 7.486 0 015.855 2.812A8.224 8.224 0 0112 20.25a8.224 8.224 0 01-5.855-2.438zM15.75 9a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" clipRule="evenodd" />
            </svg>
            </span>
             Shiva</p>
          <h1 className='text-[2rem]'>Dashboard</h1>
          <button className=" text-white bg-[#020205] font-medium rounded-md text-sm w-full sm:w-auto block px-5 py-2.5 text-center">Logout</button>
        </div>
        {/* view */}
        <div >
        <Outlet />
        </div>
      </div>
    </div>
  )
}
 
export default AdminDash
